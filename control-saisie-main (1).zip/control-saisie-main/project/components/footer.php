<footer class="footer">
   &copy; copyright @ <?= date('Y'); ?> by <span>mr. web designer</span> | all rights reserved!
</footer>