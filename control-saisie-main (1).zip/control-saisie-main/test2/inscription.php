<?php 

  echo'traitement';
?>